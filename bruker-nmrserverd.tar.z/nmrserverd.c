//#define DEBUG

/* defining DEBUG will remove code in main() that makes this a daemon!
It will not immediately fork and close STDIN, STDOUJT and STDERR,
but will stay in the forground and print lots of messages to tell
you what it is doing. */

//#define PASSREQ
#define SOCKBUFSIZE 1600
#define _BSD_SIGNALS

#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <signal.h>
#include <stdlib.h>
#include <malloc.h>
#include <time.h>
#include <sys/wait.h>
#include <ctype.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <syslog.h>
#include <pwd.h>
#include <crypt.h>
#include <math.h>

#include "omega_header.h"
#include "jcamp.h"

#ifdef DEBUG
#endif

int atoport(char *service, char *proto)
{
	int port;
	long int lport;
	struct servent *serv;
	char *errpos;

	serv = getservbyname( service, proto );
	if (serv != NULL)
		port = serv->s_port;
	else {
		lport = strtol( service, &errpos, 0 );
		if ( errpos[0] || lport < 1 || lport > 65535 ) return -1;
		port = htons( lport );
	}
	return port;
}

struct in_addr *atoaddr(char *address)
{
	struct hostent *host;
	static struct in_addr saddr;

	saddr.s_addr = inet_addr( address );
	if (saddr.s_addr != -1) return &saddr;
	host = gethostbyname( address );
	if ( host != NULL ) return (struct in_addr *)*host->h_addr_list;
	return NULL;
}

int get_connection(int socket_type, u_short port, int *listener, struct sockaddr *inhostaddr, int *inhostaddr_len)
{
	struct sockaddr_in address;
	int listening_socket;
	int connected_socket = -1;
	int new_process;
	int reuse_addr = 1;

	memset( (char *)&address, 0, sizeof( address ) );
	address.sin_family = AF_INET;
	address.sin_port = port;
	address.sin_addr.s_addr = htonl( INADDR_ANY );

	listening_socket = socket( AF_INET, socket_type, 0 );
	if ( listening_socket < 0 ) {
		perror( "socket" );
		exit( -1 );
	}

	if ( listener != NULL ) *listener = listening_socket;

	setsockopt( listening_socket, SOL_SOCKET, SO_REUSEADDR,
								&reuse_addr, sizeof( reuse_addr ) );

	if ( bind( listening_socket, (struct sockaddr *)&address, 
											sizeof( address ) ) < 0 ) {
		perror( "bind" );
		close( listening_socket );
		exit( -1 );
	}

	if ( socket_type == SOCK_STREAM ) {
		listen( listening_socket, 5 );
		while( connected_socket < 0 ) {
			connected_socket = accept( listening_socket, inhostaddr, inhostaddr_len );
			if ( connected_socket < 0 ) {
				if ( errno != EINTR ) {
					perror( "accept" );
					close( listening_socket );
					exit( -1 );
				} else
					continue;
			}
			new_process = fork();
			if ( new_process < 0 ) {
				perror( "fork" );
				close( connected_socket );
				connected_socket = -1;
			} else {
				if ( new_process == 0 ) {
					/* THIS IS THE CHILD */
					close(listening_socket);
					*listener = -1;
				} else {
					close(connected_socket);
					connected_socket = -1;
				}
			}
		}
		return connected_socket;
	} else
		return listening_socket;
}

int sock_read(int sockfd, char *buf, size_t count)
{
	size_t bytes_read = 0;
	int this_read;

	while (bytes_read < count ) {
		do
			this_read = read( sockfd, buf, count-bytes_read );
		while ( this_read<0 && errno==EINTR );
		if ( this_read <= 0 ) {
			return this_read;
		}
		bytes_read += this_read;
		buf += this_read;
	}
	return count;
}

int sock_write(int sockfd, char *buf, size_t count)
{
	size_t bytes_sent = 0;
	int this_write;

	while ( bytes_sent < count ) {
		do
			this_write = write( sockfd, buf, count-bytes_sent );
		while ( this_write<0 && errno==EINTR );
		if  (this_write <= 0 ) {
#ifdef DEBUG
			printf("write() returned a -1, errno = %d\n", errno );
#endif
			return this_write;
		}
		bytes_sent += this_write;
		buf += this_write;
	}
	return count;
}

int sock_gets(int sockfd, char *str, size_t count)
{
	int bytes_read;
	int total_count = 0;
	char *current_position;
	char last_read = 0;

	current_position = str;
	while ( last_read != '\n' ) {
		bytes_read = read( sockfd, &last_read, 1 );
		if ( bytes_read <= 0 ) {
#ifdef DEBUG
			printf("sock_gets() errno = %d\n", errno );
#endif
			return -1;
		}
		if ( total_count++ < count && last_read != '\n' )
			*current_position++ = last_read;
	}
	if ( count > 0 ) *current_position = (char)NULL;
	return total_count;
}

int sock_puts(int sockfd, char *str)
{
	return sock_write(sockfd, str, strlen(str));
}

SANE_HD hd;

typedef struct fhtag {
	char *key, *type, *value;
	struct fhtag *next;
} FH;

FH *fh = (FH *)NULL;

static void changedir(char *name)
{
	//struct stat st;
	//static char *nmr = "nmr";
	//static char *dd = "../";
	chdir( name );
	//if ( 0 == stat( nmr, &st ) ) {
	//	if ( S_ISDIR( st.st_mode ) ) {
	//		if ( strcmp( name, dd ) )
	//			chdir( nmr );
	//		else
	//			chdir( dd );
	//	}
	//}
}

static int is_num(const char *p)
{
	while (*p) {
		if (! isdigit(*p++)) {
			return 0;
		}
	}
	return 1;
}

static int dirsort(const void *v1, const void *v2)
{
	const struct direct *d1 = (const struct direct *)v1;
	const struct direct *d2 = (const struct direct *)v2;
	if (is_num(d1->d_name)) {
		if (is_num(d2->d_name)) 
			return (atoi(d1->d_name) - atoi(d2->d_name));
		else
			return 1;
	} else {
		if (is_num(d2->d_name))
			return -1;
		else
			return strcmp(d1->d_name, d2->d_name);	
	}
}

static int seldir(const struct direct *d)
{
	if (strcmp(d->d_name, ".")) {
		return (d->d_type == DT_DIR);
	} else 
		return 0;
}

static int seldir_n(const struct direct *d)
{
	if (seldir(d)) {
		return is_num(d->d_name);
	} else
		return 0;
}

static void listdirectory(int sock, int onlyspectra, int dimen)
{
	int d, e, p, fidfound, specfound;
	char namebuf[SOCKBUFSIZE];
	char *fstr, *estr, *pstr;
	struct stat statbuf;
	struct direct **dirlist, **explist, **prolist;
	JCPAR *ppar;
	int ecount, pcount;
	/* LIST DIRECTORIES IN THE CURRENT DIRECTORY */
	int dcount = scandir(".", &dirlist, &seldir, &dirsort);
	for (d=0; d<dcount; d++) {
		/* fstr WILL CONTAIN EACH DIRECTORY NAME */
		fstr = dirlist[d]->d_name;
		/* LIST DIRECTORIES IN fstr THAT HAVE NUMERIC NAMES */
		ecount = scandir(fstr, &explist, &seldir_n, &dirsort);
		for (e=0; e<ecount; e++) {
			fidfound = 0;
			/* estr IS THE EXPERIMENT NUMBER DIRECTORY NAME */
			estr = explist[e]->d_name;
			sprintf(namebuf, "%s/%s/ser", fstr, estr);
			if (! stat(namebuf, &statbuf)) {
				sprintf(namebuf, "%s/%s/acqu2s", fstr, estr);
				if (! stat(namebuf, &statbuf)) {
					sprintf(namebuf, "%s/%s/acqus", fstr, estr);
					if (! stat(namebuf, &statbuf)) {
						fidfound = 1; /* THERE IS AN ser, acqus AND acqu2s FILE */
                    }
				}
			}
			if (1 == dimen) {
				if (fidfound) {
					fidfound = 0;
					/* MAKE SURE THE 2D FILE FOUND IS ACTUALLY AN "ARRAY"ED FILE */
					sprintf(namebuf, "%s/%s/acqus", fstr, estr);
					if (readjcamp(namebuf)) {
						if (ppar = findpar("VDLIST")) {
							sprintf(namebuf, "%s/%s/%s", fstr, estr, ppar->value[0]);
							if (! stat(namebuf, &statbuf))
								fidfound = 1;
							else {
								sprintf(namebuf, "%s/%s/vdlist", fstr, estr);
								if (! stat(namebuf, &statbuf))
									fidfound = 1;
							}
						}
						if (! fidfound) {
							if (ppar = findpar("VPLIST")) {
								sprintf(namebuf, "%s/%s/%s", fstr, estr, ppar->value[0]);
								if (!stat(namebuf, &statbuf))
									fidfound = 1;
								else {
									sprintf(namebuf, "%s/%s/vplist", fstr, estr);
									if (! stat(namebuf, &statbuf))
										fidfound = 1;
								}
							}
							if (! fidfound) {
								if (ppar = findpar("VCLIST")) {
									sprintf(namebuf, "%s/%s/%s", fstr, estr, ppar->value[0]);
									if (! stat(namebuf, &statbuf))
										fidfound = 1;
									else {
										sprintf(namebuf, "%s/%s/vclist", fstr, estr);
										if (! stat(namebuf, &statbuf))
											fidfound = 1;
									}
								}
								if (! fidfound) {
									if (ppar = findpar("VTLIST")) {
										sprintf(namebuf, "%s/%s/%s", fstr, estr, ppar->value[0]);
										if (! stat(namebuf, &statbuf))
											fidfound = 1;
										else {
											sprintf(namebuf, "%s/%s/vtlist", fstr, estr);
											if (! stat(namebuf, &statbuf))
												fidfound = 1;
										}
									}
								}
							}
						}
						freepar();
					}
				} else {
					/* LOOK FOR TRUE 1D FILE */
					sprintf(namebuf, "%s/%s/fid", fstr, estr);
					if (! stat(namebuf, &statbuf)) {
						sprintf(namebuf, "%s/%s/acqus", fstr, estr);
						if (! stat(namebuf, &statbuf))
							fidfound = 1;
					}
				}
			}
			if (fidfound) {	/* THE FID WAS FOUND, LOOK FOR PROCESSED FILE */
				if (! onlyspectra) {
					sprintf(namebuf, "%s/%s\n", fstr, estr);
					sock_puts(sock, namebuf);
				}
				/* LIST EACH NUMERIC PROCESS DIRECTORY */
				sprintf(namebuf, "%s/%s/pdata", fstr, estr);
				pcount = scandir(namebuf, &prolist, &seldir_n, &dirsort);
				for (p=0; p<pcount; p++) {
					specfound = 0;
					pstr = prolist[p]->d_name;
					sprintf(namebuf, "%s/%s/pdata/%s/2rr", fstr, estr, pstr);
					if (! stat(namebuf, &statbuf)) {
						sprintf(namebuf, "%s/%s/pdata/%s/2ii", fstr, estr, pstr);
						if (onlyspectra || !stat(namebuf, &statbuf)) {
							sprintf(namebuf, "%s/%s/pdata/%s/procs", fstr, estr, pstr);
							if (! stat(namebuf, &statbuf))
								specfound = 1;
						}
					}
					if (1==dimen && 0==specfound) {
						sprintf(namebuf, "%s/%s/pdata/%s/1r", fstr, estr, pstr);
						if (! stat(namebuf, &statbuf)) {
							sprintf(namebuf, "%s/%s/pdata/%s/1i", fstr, estr, pstr);
							if (! stat(namebuf, &statbuf)) {
								sprintf(namebuf, "%s/%s/pdata/%s/procs", fstr, estr, pstr);
								if (! stat(namebuf, &statbuf))
									specfound = 1;
							}
						}
					}
					if (specfound) {
						sprintf(namebuf, "%s/%s/pdata/%s\n", fstr, estr, pstr);
						sock_puts(sock, namebuf);
					}
					free(prolist[p]);
				}
				if (pcount > 0) free(prolist);
			}
			free(explist[e]);
		}
		if (ecount > 0) {
			free(explist);
		} else {	
			sprintf(namebuf, "%s/\n", fstr);
			sock_puts(sock, namebuf);
		}
		free(dirlist[d]);
	}
	if (dcount) free(dirlist);
	sock_puts(sock, ".\n");
	return;
}

static void flexheader(int sock, char *key, char *type, char *value)
{
	char str[8];
	int tot;
	tot = strlen( key ) + strlen( value ) + 3;
	if ( type ) tot += strlen( type );
	sprintf( str, "%d\n", tot );
	sock_puts( sock, str );
	sock_write( sock, key, strlen( key ) + 1 );
	str[0] = (char)NULL;
	if ( type )
		sock_write( sock, type, strlen( type ) + 1 );
	else
		sock_write( sock, str, 1 );
	sock_write( sock, value, strlen( value ) + 1 );
	return;
}

static void fh2mem(char *key, char *type, char *value)
{
	int n1, n2, n3;
	FH *newfh;
	char *newkey;
	
	n1 = 1 + (key ? strlen(key) : 0);
	n2 = 1 + (type ? strlen(type) : 0);
	n3 = 1 + (value ? strlen(value) : 0);
	if (n1==1 || n3==1) return;
#ifdef DEBUG
	printf("fh2mem(%s, %s, %s) ", key, (type?type:"NULL"), value);
#endif
	newkey = calloc(n1 + n2 + n3, sizeof(char));
	if (! newkey)
		return;
	strcpy(newkey, key);
	if (n2 > 1)
		strcpy(newkey+n1, type);
	strcpy(newkey+n1+n2, value);
	newfh = fh;
	while (newfh) {			/* SEARCH THE EXISTING FH */
		if (strcmp(newfh->key, key)) {
							/* NO MATCH... */
			if (newfh->next)
				newfh = newfh->next;	/* THERE IS A NEXT, GO ON */
			else {
				/* AT THE END OF THE LIST, CREATE NEW AND ADD IT TO THE TAIL */
				if (newfh->next = malloc(sizeof(FH))) {
					newfh = newfh->next;
					newfh->next = NULL;
					newfh->key = newkey;
					newfh->type = (n2 > 1) ? newkey+n1 : NULL;
					newfh->value = newkey + n1 + n2;
#ifdef DEBUG
					printf("added to tail\n");
#endif
					return;
				} else {	/* PROBLEMS CREATING NEW FH ITEM, BAIL OUT */
					free(newkey);
					return;
				}
			}
		} else {			/* A KEY MATCH! REPLACE key, type AND value.
							   BUT DON'T SCREW AROUND WITH THE next POINTER! */
			free(newfh->key);
			newfh->key = newkey;
			newfh->type = (n2 > 1) ? newkey+n1 : NULL;
			newfh->value = newkey + n1 + n2;
#ifdef DEBUG
			printf("REDEFINITION!\n");
#endif
			return;
		}
	}
	/* FIRST ITEM IN FH! */
	if (fh = malloc(sizeof(FH))) {
		fh->next = NULL;
		fh->key = newkey;
		fh->type = (n2 > 1) ? newkey+n1 : NULL;
		fh->value = newkey + n1 + n2;
#ifdef DEBUG
		printf("first item!\n");
#endif
	}
	return;
}

static void freefh()
{
	FH *current;
	while ( fh) {
		current = fh;
		fh = current->next;
		free( current->key );
		free( current );
	}
	return;
}

float phaselookup(int decim, int dspfvs)
{
	switch( dspfvs ) {
	case 10:
		switch( decim ) {
		case 2:
			return (float)(179.0 * 180.0 / decim );
		case 3:
			return (float)(201.0 * 180.0 / decim  );
		case 4:
			return (float)(533.0 * 180.0 / decim  );
                case 6:
                        return (float)(709.0 * 180.0 / decim  );
                case 8:
                        return (float)(1097.0 * 180.0 / decim  );
                case 12:
                        return (float)(1449.0 * 180.0 / decim  );
                case 16:
                        return (float)(2225.0 * 180.0 / decim  );
                case 24:
                        return (float)(2929.0 * 180.0 / decim  );
                case 32:
                        return (float)(4481.0 * 180.0 / decim  );
                case 48:
                        return (float)(5889.0 * 180.0 / decim  );
                case 64:
                        return (float)(8993.0 * 180.0 / decim  );
                case 96:
                        return (float)(11809.0 * 180.0 / decim  );
                case 128:
                        return (float)(18017.0 * 180.0 / decim  );
                case 192:
                        return (float)(23649.0 * 180.0 / decim  );
                case 256:
                        return (float)(36065.0 * 180.0 / decim  );
                case 384:
                        return (float)(47329.0 * 180.0 / decim  );
                case 512:
                        return (float)(72161.0 * 180.0 / decim  );
                case 768:
                        return (float)(94689.0 * 180.0 / decim  );
                case 1024:
                        return (float)(144353.0 * 180.0 / decim  );
                case 1536:
                        return (float)(189409.0 * 180.0 / decim );
                case 2048:
                        return (float)(288737.0 * 180.0 / decim );
		}
		break;
        case 11:
                switch( decim ) {
                case 2:
                        return (float)(184.0 * 180.0 / decim );
                case 3:
                        return (float)(219.0 * 180.0 / decim  );
                case 4:
                        return (float)(384.0 * 180.0 / decim  );
                case 6:
                        return (float)(602.0 * 180.0 / decim  );
                case 8:
                        return (float)(852.0 * 180.0 / decim  );
                case 12:
                        return (float)(1668.0 * 180.0 / decim  );
                case 16:
                        return (float)(2312.0 * 180.0 / decim  );
                case 24:
                        return (float)(3368.0 * 180.0 / decim  );
                case 32:
                        return (float)(4656.0 * 180.0 / decim  );
                case 48:
                        return (float)(6768.0 * 180.0 / decim  );
                case 64:
                        return (float)(9344.0 * 180.0 / decim  );
                case 96:
                        return (float)(13568.0 * 180.0 / decim  );
                case 128:
                        return (float)(18560.0 * 180.0 / decim  );
                case 192:
                        return (float)(27392.0 * 180.0 / decim  );
                case 256:
                        return (float)(36992.0 * 180.0 / decim  );
                case 384:
                        return (float)(55040.0 * 180.0 / decim  );
                case 512:
                        return (float)(73856.0 * 180.0 / decim  );
                case 768:
                        return (float)(110336.0 * 180.0 / decim  );
                case 1024:
                        return (float)(147584.0 * 180.0 / decim  );
                case 1536:
                        return (float)(220928.0 * 180.0 / decim );
                case 2048:
                        return (float)(295040.0 * 180.0 / decim );
                }
		break;
        case 12:
                switch( decim ) {
                case 2:
                        return (float)(184.0 * 180.0 / decim );
                case 3:
                        return (float)(219.0 * 180.0 / decim  );
                case 4:
                        return (float)(384.0 * 180.0 / decim  );
                case 6:
                        return (float)(602.0 * 180.0 / decim  );
                case 8:
                        return (float)(852.0 * 180.0 / decim  );
                case 12:
                        return (float)(1668.0 * 180.0 / decim  );
                case 16:
                        return (float)(2292.0 * 180.0 / decim  );
                case 24:
                        return (float)(3368.0 * 180.0 / decim  );
                case 32:
                        return (float)(4616.0 * 180.0 / decim  );
                case 48:
                        return (float)(6768.0 * 180.0 / decim  );
                case 64:
                        return (float)(9264.0 * 180.0 / decim  );
                case 96:
                        return (float)(13568.0 * 180.0 / decim  );
                case 128:
                        return (float)(18560.0 * 180.0 / decim  );
                case 192:
                        return (float)(27392.0 * 180.0 / decim  );
                case 256:
                        return (float)(36992.0 * 180.0 / decim  );
                case 384:
                        return (float)(55040.0 * 180.0 / decim  );
                case 512:
                        return (float)(73856.0 * 180.0 / decim  );
                case 768:
                        return (float)(110336.0 * 180.0 / decim  );
                case 1024:
                        return (float)(147584.0 * 180.0 / decim  );
                case 1536:
                        return (float)(220928.0 * 180.0 / decim );
                case 2048:
                        return (float)(295040.0 * 180.0 / decim );
                }
		break;
        case 13:
                switch( decim ) {
                case 2:
                        return (float)(11.0 * 180.0 / decim );
                case 3:
                        return (float)(17.0 * 180.0 / decim  );
                case 4:
                        return (float)(23.0 * 180.0 / decim  );
                case 6:
                        return (float)(35.0 * 180.0 / decim  );
                case 8:
                        return (float)(47.0 * 180.0 / decim  );
                case 12:
                        return (float)(71.0 * 180.0 / decim  );
                case 16:
                        return (float)(95.0 * 180.0 / decim  );
                case 24:
                        return (float)(143.0 * 180.0 / decim  );
                case 32:
                        return (float)(191.0 * 180.0 / decim  );
                case 48:
                        return (float)(287.0 * 180.0 / decim  );
                case 64:
                        return (float)(383.0 * 180.0 / decim  );
                case 96:
                        return (float)(575.0 * 180.0 / decim  );
                }
                break;
	}
	return (float)0.0;
}

#define HEADERONLY 1
#define ALLDATA 0

static void getspectrum(int sock, char *file, int dimen)
{
	int np[2];
	float fdata[6];
	char f1nuca[8], f1nucb[8], f2nuca[8], f2nucb[8];
	char pulprog[64];
	char *fstr, path[PATH_MAX];
	char *comment, *dataclass, *sample, *tok;
	int i, bytordp = 0, nc_proc = 0;
	int *pint;
	unsigned int ui;
	static char *acqu = "acqus";
	static char *pro = "procs";
	static char *pro2 = "proc2s";
	static char *tworr = "2rr";
	static char *oner = "1r";
	static char *info = "sample_info.prop";
	static char *up = "%s/../../%s";
	static char *down = "%s/%s";
	FILE *nmr;
	JCPAR *ppar;
	
	hd.ftflag[1] = hd.ftflag[0] = 1;

	f1nuca[0] = f1nucb[0] = f2nuca[0] = f2nucb[0] = (char)NULL;
	sprintf( path, up, file, acqu );
	if (readjcamp(path)) {
		ppar = findpar("NUCLEUS");
		if (ppar) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f1nuca, ppar->value[0]);
		}
		ppar = findpar("DECNUC");
		if (ppar) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f2nuca, ppar->value[0]);
		}
		ppar = findpar("NUC1");
		if (ppar) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f1nucb, ppar->value[0]);
		}
		ppar = findpar("NUC2");
		if (ppar) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f2nucb, ppar->value[0]);
		}
		ppar = findpar("PULPROG");
		if (ppar) {
			if (strlen(ppar->value[0]) < 64)
				strcpy(pulprog, ppar->value[0]);
		}
		freepar();
	}

	/* THERE SEEMS TO BE A DIFFERENCE BETWEEN AN AMX AND AN AVANCE,
	   AMX USES 'NUCLEUS' AND 'DECNUC' WHILE AVANCE USES 'NUC1' AND 'NUC2' */
	if ( strcmp( f1nuca, "off") || strcmp(f2nuca, "off") ) {
		strcpy( f1nucb, f1nuca );
		strcpy( f2nucb, f2nuca );
	}
	
	sprintf( path, down, file, pro );
	if (readjcamp(path)) {
		if (ppar = findpar("BYTORDP"))
			bytordp = atoi(ppar->value[0]);
		if (ppar = findpar("FTSIZE"))
			np[0] = atoi(ppar->value[0]);
		if (ppar = findpar("NC_proc"))
			nc_proc = atoi(ppar->value[0]);
		if (ppar = findpar("OFFSET"))
			fdata[2] = (float)atof(ppar->value[0]);
		if (ppar = findpar("SF"))
			fdata[0] = (float)atof(ppar->value[0]);
		if (ppar = findpar("SW_p"))
			fdata[1] = (float)atof(ppar->value[0]);
		freepar();
	}
	
	np[1] = 1;
	if (2 == dimen) {
		sprintf( path, down, file, pro2 );
		if (readjcamp(path)) {
			if (ppar = findpar("FTSIZE"))
				np[1] = atoi(ppar->value[0]);
			if (ppar = findpar("SF"))
				fdata[3] = (float)atof(ppar->value[0]);
			if (ppar = findpar("SW_p"))
				fdata[4] = (float)atof(ppar->value[0]);
			if (ppar = findpar("OFFSET"))
				fdata[5] = (float)atof(ppar->value[0]);
			if (2 > np[1]) {
				if (ppar = findpar("TDeff"))
					np[1] = atoi(ppar->value[0]);
			}
			freepar();
		}
	}
	
	/* GET INFO FILE FOR ADDITIONAL FLEXHEADER ITEMS */
	sample = comment = NULL;
	sprintf( path, up, file, info );
	if (fstr = file2mem(path)) {
		tok = strtok(fstr, "\r\n");
		while (tok) {
			char *s1 = strstr(tok, "=NM=");
			char *s2 = strstr(tok, ", NM2=");
			char *s3 = strstr(tok, ", HEIGHT=");
			if (s1 && s2 && s3) {
				*s3 = *s2 = (char)NULL;
				for (s3=s1+4; *s3; s3++)
					*s3 = tolower(*s3);
				if (0 == strcmp(s1, "sample"))
					sample = s3;
				else if (0 == strcmp(s1, "comment"))
					comment = s3;
				else if (0 == strcmp(s1, "dataclass"))
					dataclass = s3;
			}
			tok = strtok(NULL, "\r\n");
		}
	}
	if (sample) {
		sprintf(path, "%s\n", sample);
		sock_puts(sock, path);
	}
	if (comment) {
		sprintf(path, "%s\n", comment);
		sock_puts(sock, path);
	}
	if (strlen(pulprog)) {
		strcpy(path, pulprog);
		if (strlen(f1nucb)) {
			strcat(path, " - ");
			strcat(path, f1nucb);
			if (strlen(f2nucb)) {
				strcat(path, "{");
				strcat(path, f2nucb);
				strcat(path, "}");
			}
		}
		strcat(path, "\n");
		sock_puts(sock, path);
	}
	sprintf(path, "NC_proc=%d\n", nc_proc);
	sock_puts(sock, path);
	if (dataclass) {
		sprintf(path, "dataclass=%s\n", dataclass);
		sock_puts(sock, path);
	}
	if (fstr) {
		free(fstr);
		fstr = (char *)NULL;
	}
	sock_puts(sock, ".\n");

#ifdef DEBUG
	printf("dimension=%d\n", dimen);
	printf("np[0]=%d sf=%g sw=%g of=%g\n", np[0], fdata[0], fdata[1], fdata[2]);
	printf("np[1]=%d sf=%g sw=%g of=%g\n", np[1], fdata[3], fdata[4], fdata[5]);
#endif
	i = dimen;
	ui = htonl((unsigned int)i);
	sock_write(sock, (char *)&ui, sizeof(unsigned int));
	ui = htonl((unsigned int)np[0]);
	sock_write(sock, (char *)&ui, sizeof(unsigned int));
	for (i=0; i<3; i++) {
		ui = htonl(*(unsigned int *)(fdata + i));
		sock_write(sock, (char *)&ui, sizeof(unsigned int));
	}
	if (2 == dimen) {
		ui = htonl((unsigned int)np[1]);
		sock_write(sock, (char *)&ui, sizeof(unsigned int));
		for (i=3; i<6; i++) {
			ui = htonl(*(unsigned int *)(fdata + i));
			sock_write(sock, (char *)&ui, sizeof(unsigned int));
		}
	}

	int normcon = 1;
	while (nc_proc++ < 0)
		normcon *= 2;

	pint = (int *)malloc(sizeof(int)*np[0]);
	unsigned int *pui = (unsigned int *)pint;
	if (pint ) {
		sprintf(path, down, file, (2==dimen)?tworr:oner);
		nmr = fopen( path, "r" );
		if (nmr) {
			for (i=0; i<np[1]; i++) {
				fread(pint, sizeof(int), np[0], nmr);
				if (bytordp) {
					for (i=0; i<np[0]; i++)
						pui[i] = ntohl(pui[i]);
				}
				if (normcon > 1) {
					for (i=0; i<np[0]; i++)
						pint[i] /= normcon;
				}
				for (i=0; i<np[0]; i++)
					pui[i] = htonl(pui[i]);
				sock_write( sock, (char *)pint, np[0]*sizeof(int) );
			}
			fclose( nmr );
		}
		free( pint );
	}
	return;
}

static void swapui(unsigned int *u1, unsigned int *u2)
{
	unsigned int i = *u1;
	*u1 = *u2;
	*u2 = i;
	return;
}

static void writeheader(int sock)
{
	int i;
	SANE_HD nhd;
	memcpy(&nhd, &hd, sizeof(SANE_HD));
	unsigned int *ui = (unsigned int *)&nhd;
	for (i=0; i<sizeof(SANE_HD)/4; i++) {
		switch (i) {
		case 127:
		case 128:
		case 150:
		case 151:
		case 152:
		case 174:
		case 175:
		case 212:
		case 213:
			break;
		default:
			ui[i] = htonl(ui[i]);
			break;
		}
	}
	for (i=0; i<36; i+=2)
		swapui(ui+i, ui+i+1);
	for (i=116; i<122; i+=2)
		swapui(ui+i, ui+i+1);
	for (i=132; i<138; i+=2)
		swapui(ui+i, ui+i+1);
	for (i=156; i<162; i+=2)
		swapui(ui+i, ui+i+1);
	for (i=194; i<200; i+=2)
		swapui(ui+i, ui+i+1);
	sock_write(sock, (char *)&nhd, sizeof(SANE_HD));
}

static void getfile(int sock, char *file)
{
	char f1nuca[8], f1nucb[8], f2nuca[8], f2nucb[8];
	char buf1[16], buf2[16], path[PATH_MAX], *tok;
	char line[256], *ss;
	char *fstr, *farray, *parrayname;
	char cnst[64], cpd[8], cpdamx[2], d[64], dl[64], l[64], p[64], pcpd[64], pl[64], tl[64];
	int i, j, *pint, wdw = 0;
	int decim = 0, dspfvs = 0;
	int norcon = 0, bytord = 0;
	time_t longtime;
	double x, lb, gm;
	double grpdly = 0.0;
	float *pfl, fnorcon;
	static char *pp = "format.temp";
	static char *acqus = "acqus";
	static char *acqu2s = "acqu2s";
	static char *procs = "procs";
	static char *info = "info";
	static char *up = "%s/../../%s";
	static char *down = "%s/%s";
	static char *stitle = "sample_info.prop";
	static char *space = " \t\r\n";
	FILE *nmr, *refile, *imfile;
	FH *current;
	JCPAR *ppar;

	f1nuca[0] = f1nucb[0] = f2nuca[0] = f2nucb[0] = (char)NULL;
	/* FID or SPECTRUM? */
	if (strstr(file, "/pdata/")) {
		hd.ftflag[0] = 1;
		ss = up;
	} else {
		hd.ftflag[0] = 0;
		ss = down;
	}
#ifdef DEBUG
	printf("%s is a %s\n", file, hd.ftflag[0]?"spectrum":"fid");
#endif
		
	/* LOOK IN THE PULSE PROGRAM AND FIND WHICH VARS ARE BEING USED */
	for ( i=0; i<64; i++ ) {
		if (i < 2)
			cpdamx[i] = '-';
		if ( i < 8 )
			cpd[i] = '-';
		cnst[i] = d[i] = dl[i] = l[i] = p[i] = pcpd[i] = pl[i] = tl[i] = '-';
	}
	sprintf( path, ss, file, pp );
	fstr = file2mem(path);
	if (fstr) {
		tok = strtok(fstr, space);
		while (tok) {
			if (0 == strncmp(tok, "T_NAME", 6)) {
				tok = strtok(NULL, space);
				switch( tok[0] ) {
				case 'C':
					if (0==strncmp(tok, "CNST", 4) && isdigit(tok[4])) {
						i = atoi(tok+4);
						if (i < 64)
							cnst[i] = '+';
					} else if (0 == strncmp(tok, "CPD", 3)) {
						if (isdigit(tok[3])) {
							i = atoi(tok+3);
							if (i < 8)
								cpd[i] = '+';
						} else if ('T' == tok[3])
							cpdamx[0] = '+';
						else
							cpdamx[1] = '+';
					}
					break;
				case 'D':
					if ('L'==tok[1] && isdigit(tok[2])) {
						i = atoi(tok+2);
						if (i < 64)
							dl[i] = '+';
					} else if (isdigit(tok[1])) {
						i = atoi(tok+1);
						if (i < 64)
							d[i] = '+';
					}
					break;
				case 'L':
					if (isdigit(tok[1])) {
						i = atoi(tok+1);
						if (i < 64)
							l[i] = '+';
					}
					break;
				case 'P':
					if (isdigit(tok[1])) {
						i = atoi(tok+1);
						if (i < 64)
							p[i] = '+';
					} else if ('L'==tok[1] && isdigit(tok[2])) {
						i = atoi(tok+2);
						if (i < 64)
							pl[i] = '+';
					} else if (0==strncmp(tok, "PCPD", 4) && isdigit(tok[4])) {
						i = atoi(tok+4);
						if (i < 64)
							pcpd[i] = '+';
					}
					break;
				case 'T':
					if ('L'==tok[1] && isdigit(tok[2])) {
						i = atoi(tok+2);
						if (i < 64)
							tl[i] = '+';
					}
					break;
				}
			} /* token was T_NAME */
			tok = strtok(NULL, space);
		} /* chew up tokens */
		free(fstr);
	} /* if we have a fstr */

	hd.dim[1] = 1;
	hd.dimension = 1;
	sprintf(path, ss, file, acqu2s);
	if (readjcamp(path)) {
		hd.dimension = 2;
		if (ppar = findpar("TD"))
			hd.dim[1] = atoi(ppar->value[0]);
		freepar();
	}
#ifdef DEBUG
	printf("hd.dimension=%d hd.dim[1]=%d\n", hd.dimension, hd.dim[1]);
#endif

	sprintf(path, ss, file, acqus);
	hd.f2.hetero_flag = 'b';
	if (readjcamp(path)) {
#ifdef DEBUG
		printf("Read jcamp file %s\n", path);
#endif
		if (ppar = findpar("AQ_mod"))
			hd.acqmode = atoi(ppar->value[0]) + 10;
		if (ppar = findpar("BF1"))
			hd.dim_freq[0] = atof(ppar->value[0]);
		if (ppar = findpar("BF2"))
			hd.dim_freq[1] = atof(ppar->value[0]);
		if ('+' == cpdamx[0]) {
			if (ppar = findpar("CPDPRGT")) {
				fh2mem("CPDPRGT", "sequel", ppar->value[0]);
			}
		}
		if ('+' == cpdamx[1]) {
			if (ppar = findpar("CPDPRG")) {
				fh2mem("CPDPRG", "sequel", ppar->value[0]);
			}
		}
		for (i=0; i<8; i++) {
			if ('+' == cpd[i]) {
				sprintf(buf1, "CPDPRG%d", i);
				if (ppar = findpar(buf1)) {
					fh2mem(buf1, "sequel", ppar->value[0]);
					if (strstr(ppar->value[0], "mlev"))
						hd.f2.rom_program = 1;
					else if (strstr(ppar->value[0], "waltz"))
						hd.f2.rom_program = 3;
					else if (strstr(ppar->value[0], "bb"))
						hd.f2.rom_program = 8;
					else if (strstr(ppar->value[0], "garp"))
						hd.f2.rom_program = 9;
					else if (strstr(ppar->value[0], "tppm"))
						hd.f2.rom_program = 12;
					else
						hd.f2.rom_program = 999;
				}
			}
		}
		if (ppar = findpar("PCPD") ) {
			if ('+'==cpd[2] && '+'==pcpd[2] && ppar->vcount > 1) {
				hd.f2.rate = (float)(2.5e5 / atof(ppar->value[1]));
			}
		}
		if (ppar = findpar("BYTORDA"))
			bytord = atoi(ppar->value[0]);
		if (ppar = findpar("CNST")) {
			for (i=0; i<ppar->vcount; i++) {
				if ('+' == cnst[i]) {
					sprintf(buf1, "CNST%d", i);
					fh2mem(buf1, "seqel", ppar->value[i]);
				}
			}
		}
		if (ppar = findpar("D")) {
			for (i=0; i<ppar->vcount; i++) {
				if ('+' == d[i]) {
					sprintf(buf1, "D%d", i);
					x = atof(ppar->value[i]);
					if (x < 1.0e-3)
						sprintf(buf2, "%gus", 1.0e6*x);
					else if (x < 1.0)
						sprintf(buf2, "%gus", 1.0e3*x);
					else
						sprintf(buf2, "%gs", x);
					fh2mem(buf1, "sequel", buf2);
				}
			}
		}
		if (ppar = findpar("DATE")) {
			longtime = (time_t)atol(ppar->value[0]);
			tok = ctime( &longtime );
			if ('\n' == tok[strlen(tok)-1])
				tok[strlen(tok)-1] = (char)NULL;
			fh2mem("date", NULL, tok);
		}
		if (ppar = findpar("DL")) {
			for (i=0; i<ppar->vcount; i++) {
				if ('+' == dl[i]) {
					sprintf(buf1, "DL%d", i);
					fh2mem(buf1, "sequel", ppar->value[i]);
				}
			}
		}
		if (ppar = findpar("DECIM"))
			decim = atoi(ppar->value[0]);
		if (ppar = findpar("DS"))
			hd.dg = atoi(ppar->value[0]);
		if (ppar = findpar("DSPFVS"));
			dspfvs = atoi(ppar->value[0]);
		if (ppar = findpar("GRPDLY"))
			grpdly = atof(ppar->value[0]);
		if (ppar = findpar("L")) {
			for (i=0; i<ppar->vcount; i++) {
				if ('+' == l[i]) {
					sprintf(buf1, "L%d", i);
					fh2mem(buf1, "sequel", ppar->value[i]);
				}
			}
		}
		if (ppar = findpar("LGAIN"))
			hd.lock.gain = atoi(ppar->value[0]);
		if (ppar = findpar("LOCKPOW"))
			hd.lock.power = atoi(ppar->value[0]);
		if (ppar = findpar("LOCNUC")) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(hd.lock.nucleus, ppar->value[0]);
		}
		if (ppar = findpar("NS"))
			hd.ns = atoi(ppar->value[0]);
		if (ppar = findpar("NUCLEUS")) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f1nuca, ppar->value[0]);
		}
		if (ppar = findpar("DECNUC")) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f2nuca, ppar->value[0]);
		}
		if (ppar = findpar("NUC1")) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f1nucb, ppar->value[0]);
		}
		if (ppar = findpar("NUC2")) {
			if (strlen(ppar->value[0]) < 8)
				strcpy(f2nucb, ppar->value[0]);
		}
		if (ppar = findpar("O1"))
			hd.of[0] = (float)atof(ppar->value[0]);
		if (ppar = findpar("O2")) {
			hd.of[1] = (float)atof(ppar->value[0]);
			hd.f2.nu_offset = hd.of[1] / hd.dim_freq[1];
		}
		if (ppar = findpar("P")) {
			for (i=0; i<ppar->vcount; i++) {
				if ( '+' == p[i] ) {
					sprintf(buf1, "P%d", i);
					x = atof(ppar->value[i]);
					if (x > 100000.0)
						sprintf(buf2, "%gs", 1.0e-6*x);
					else if (x > 1000.0)
						sprintf(buf2, "%gms", x*1.0e-3);
					else
						sprintf(buf2, "%gus", x);
					fh2mem(buf1, "sequel", buf2);
				}
			}
		}
		if (ppar = findpar("PL")) {
			for ( i=0; i<ppar->vcount; i++ ) {
				if ('+' == pl[i]) {
					sprintf(buf1, "PL%d", i);
					fh2mem(buf1, "sequel", ppar->value[i]);
				}
			}
		}
		if (ppar = findpar("PROBHD"))
			fh2mem("Probe", "sequel", ppar->value[0]);
		if (ppar = findpar("PULPROG"))
			fh2mem("seq_source", "seq_source", ppar->value[0]);
		if (ppar = findpar("TL")) {
			for (i=0; i<ppar->vcount; i++) {
				if ('+' == tl[i]) {
					sprintf(buf1, "TL%d", i);
					fh2mem(buf1, "sequel", ppar->value[0]);
				}
			}
		}
		if (ppar = findpar("RG")) 
			hd.gain.gain_val = (float)atof(ppar->value[0]);
		if (ppar = findpar("SFO1"))
			hd.f1.freq = atof(ppar->value[0]);
		if (ppar = findpar("SFO2"))
			hd.f2.freq = atof(ppar->value[0]);
		if (ppar = findpar("SOLVENT")) {
			if (strlen(ppar->value[0]))
				fh2mem("LockSolvent", NULL, ppar->value[0]);
		}
		if (ppar = findpar("SW_h")) {
			hd.spec_width[0] = atof(ppar->value[0]);
			hd.dwell_time[0] = 1.0 / hd.spec_width[0];
#ifdef DEBUG
			printf("SW_h = %g\n", hd.spec_width[0]);
#endif
		}
		if (ppar = findpar("TD"))
			hd.block_size = hd.dim[0] = atoi(ppar->value[0]) / 2;
		if (ppar = findpar("TE")) {
			hd.vt.set_point = (float)(atof(ppar->value[0]) - 273.15);
			hd.vt.unused1 = 1;
		}
		if (ppar = findpar("TL")) {
			for (i=0; i<ppar->vcount; i++) {
				if ('y' == tl[i]) {
					sprintf(buf1, "TL%d", i);
					fh2mem(buf1, "sequel", ppar->value[0]);
				}
			}
		}
		farray = parrayname = NULL;
		if (2 == hd.dimension) {
			sprintf(path, ss, file, "difflist");
			struct stat statbuf;
			if (0 == stat(path, &statbuf)) {
				farray = file2mem(path);
				parrayname = "DiffGradient";
				if (0 == hd.ftflag[0]) {
					for (i=1; i<101; i++) {
						sprintf(path, "%s/pdata/%d/dosy", file, i);
						if (0 == stat(path, &statbuf))
							break;
					}
				} else
					sprintf(path, down, file, "dosy");
				if (0 == stat(path, &statbuf)) {
					freepar();
					readjcamp(path);
					if (ppar = findpar("Gamma")) {
						double x = atof(ppar->value[0]);
						x *= 62813.853;
						sprintf(path, "%g", x);
						fh2mem("dosygamma", "DOSY", path);
					}
					if (ppar = findpar("Glen")) {
						double x = atof(ppar->value[0]);
						if (ppar = findpar("Gdist")) {
							double y = atof(ppar->value[0]);
							x = x * x * y * 1e-9;
						}
						sprintf(path, "%g", x);
						fh2mem("timecubed", "DOSY", path);
					}
					fh2mem("DAC_to_G", "DOSY", "1.0");
				}
			}
			if (NULL == farray) {
				ppar = findpar("VDLIST");
				sprintf(path, ss, file, ppar->value[0]);
				if (farray = file2mem(path))
					parrayname = "VD";
				else {
					sprintf(path, ss, file, "vdlist");
					if (farray = file2mem(path))
						parrayname = "VD";
				}
			}
			if (NULL == farray) {
				ppar = findpar("VPLIST");
				sprintf(path, ss, file, ppar->value[0]);
				if (farray = file2mem(path))
					parrayname = "VP";
				else {
					sprintf(path, ss, file, "vplist");
					if (farray = file2mem(path))
						parrayname = "VP";
				}
			}
			if (NULL == farray) {
				ppar = findpar("VCLIST");
				sprintf(path, ss, file, ppar->value[0]);
				if (farray = file2mem(path))
					parrayname = "VC";
				else {
					sprintf(path, ss, file, "vclist");
					if (farray = file2mem(path))
						parrayname = "VC";
				}
			}
			if (NULL == farray) {
				ppar = findpar("VTLIST");
				sprintf(path, ss, file, ppar->value[0]);
				if (farray = file2mem(path))
					parrayname = "VT";
				else {
					sprintf(path, ss, file, "vtlist");
					if (farray = file2mem(path))
						parrayname = "VT";
				}
			}
		}
		freepar();
	}

	/* THERE SEEMS TO BE A DIFFERENCE BETWEEN AN AMX AND AN AVANCE,
	   AMX USES 'NUCLEUS' AND 'DECNUC' WHILE AVANCE USES 'NUC1' AND 'NUC2' */
	if ( strcmp( f1nuca, "off") || strcmp(f2nuca, "off") ) {
		strcpy( hd.f1.nucleus, f1nuca );
		strcpy( hd.f2.nucleus, f2nuca );
	} else {
		strcpy( hd.f1.nucleus, f1nucb );
		strcpy( hd.f2.nucleus, f2nucb );
	}
	
	if (hd.ftflag[0]) {
		sprintf(path, down, file, procs);
		if (readjcamp(path)) {
			if (ppar = findpar("BYTORDP"))
				bytord = atoi(ppar->value[0]);
			if (ppar = findpar("FTSIZE"))
				hd.dim[0] = atoi(ppar->value[0]);
			if (ppar = findpar("NC_proc"))
				norcon = atoi(ppar->value[0]);
			if (ppar = findpar("WDW"))
				wdw = atoi(ppar->value[0]);
			if (ppar = findpar("LB"))
				lb = atof(ppar->value[0]);
			if (ppar = findpar("GM"))
				gm = atof(ppar->value[0]);
			freepar();
		}
		
		switch (wdw) {
			case 1:
				sprintf(buf1, "%g", lb);
				fh2mem("apo_type", NULL, "LB");
				fh2mem("apo_value", NULL, buf1);
				fh2mem("apo_unit", NULL, "Hertz");
				break;
			case 2:
				sprintf(buf1, "%g", gm);
				fh2mem("apo_type", NULL, "GM");
				fh2mem("apo_value", NULL, buf1);
				fh2mem("apo_unit", NULL, "Hertz");
				break;
		}
	} else
		if (grpdly > 0.0)
			hd.phaseb[3] = (float)(360.0 * grpdly);
		else
			hd.phaseb[3] = phaselookup(decim, dspfvs);

	hd.at = hd.dwell_time[0] * hd.block_size;

	/* GET INFO FILE FOR ADDITIONAL FLEXHEADER ITEMS */
	sprintf( path, ss, file, info );
	if (fstr = file2mem(path)) {
		tok = strtok(fstr, "\n");
		while (tok) {
			if      (0 == strncmp(tok, "CUSTOMER", 8))
				fh2mem("user", NULL, strtok(NULL, "\n"));
			else if (0 == strncmp(tok, "SAMPLE", 6))
				fh2mem("sample", NULL, strtok(NULL, "\n"));
			else if (0 == strncmp(tok, "COMMENT", 7))
				fh2mem("comment", NULL, strtok(NULL, "\n"));
			else if (0 == strncmp(tok, "WORK_ORDER", 10))
				fh2mem("workorder", NULL, strtok(NULL, "\n"));
			else if (0 == strncmp(tok, "PROJECT", 7))
				fh2mem("project", NULL, strtok(NULL, "\n"));
			else if (0 == strncmp(tok, "SUBMISSION_DATE", 15))
				fh2mem("submitted", NULL, strtok(NULL, "\n"));
			tok = strtok(NULL, "\n");
		}
		free(fstr);
	} else {
		sprintf(path, ss, file, stitle);
#ifdef DEBUG
		printf("info not found, looking for %s\n", path);
#endif
		fstr = file2mem(path);
		if (fstr) {
			char *s1, *s2, *s3;
			tok = strtok(fstr, "\r\n");
			while (tok) {
				s1 = strstr(tok, "=NM=");
				s2 = strstr(tok, ", NM2=");
				s3 = strstr(tok, ", HEIGHT=");
				if (s1 && s2 && s3) {
					*s3 = *s2 = (char)NULL;
					for (s3=s1+4; *s3; s3++)
						*s3 = tolower(*s3);
					fh2mem(s1+4, NULL, s2+6);
				}
				tok = strtok(NULL, "\r\n");
			}
			free(fstr);
		}
	}
	
	pfl = (float *)malloc(2 * sizeof(float) * hd.dim[0]);
	pint = (int *)malloc(2 * sizeof(int) * hd.dim[0]);
	if (!pint || !pfl) {
#ifdef DEBUG
		printf("ERROR: can't malloc data memory\n");
#endif
		if (pfl) free(pfl);
		if (pint) free(pint);
		if (farray) free(farray);
		freefh();
		return;
	}

	if (hd.dim[1] > 1) {
		if (parrayname && farray)
			fh2mem("array", NULL, parrayname);
		hd.groupnum = hd.dim[1];
	} else
		hd.groupnum = 0;
	nmr = refile = imfile = NULL;
	if (hd.ftflag[0]) {
		sprintf(path, down, file, (1==hd.dimension)?"1r":"2rr");
		refile = fopen(path, "r");
#ifdef DEBUG
		if (NULL==refile) printf("ERROR: can't open %s\n", path);
#endif
		sprintf(path, down, file, (1==hd.dimension)?"1i":"2ii");
		imfile = fopen(path, "r");
#ifdef DEBUG
		if (NULL==imfile) printf("ERROR: can't open %s\n", path);
#endif
		if (!refile || !imfile) {
			if (refile) fclose(refile);
			if (imfile) fclose(imfile);
			if (farray) free(farray);
			return;
		}
	} else {
		sprintf(path, down, file, (1==hd.dimension)?"fid":"ser");
#ifdef DEBUG
		printf("Opening fid at %s\n", path);
#endif
		nmr = fopen(path, "r");
#ifdef DEBUG
		if (NULL==nmr) printf("ERROR: can't open %s\n", path);
#endif
		if (! nmr) {
			if (farray) free(farray);
			return;
		}
	}
	
	fnorcon = norcon ? powf((float)2.0, (float)norcon) : 1.0;
	tok = (farray && parrayname) ? strtok(farray, " \r\t\n") : NULL;
	for (j=0; j<hd.dim[1]; j++) {
#ifdef DEBUG
		printf("Writing %d file of %d total\n", j, hd.dim[1]);
#endif
		/* UPDATE FIXED HEADER AND WRITE TO SOCKET*/
		if (hd.groupnum)
			hd.groupcur = j + 1;
		
		writeheader(sock);

		/* UPDATE FLEX HEADER AND WRITE TO SOCKET */
		if (tok) {
#ifdef DEBUG
			printf("updating %s to %s\n", parrayname, tok);
#endif
			fh2mem(parrayname, "sequel", tok);
			tok = strtok(NULL, " \r\t\n");
		}
		current = fh;
		while ( current ) {
			flexheader(sock, current->key, current->type, current->value);
			current = current->next;
		}
		sock_puts( sock, "0\n" );

		/* READ NEXT FID OR SPECTRUM AND WRITE TO SOCKET*/
#ifdef DEBUG
		printf("BYTORD%c = %d\n", hd.ftflag[0]?'P':'A', bytord);
#endif
		if ( hd.ftflag[0] ) {
			fread(pint, sizeof(int), hd.dim[0], refile);
			if (bytord) {
				unsigned int *ui = (unsigned int *)pint;
				for (i=0; i<hd.dim[0]; i++)
					ui[i] = ntohl(ui[i]);
			}
			for (i=0; i<hd.dim[0]; i++)
				pfl[i*2] = (float)pint[i] * fnorcon;
			fread(pint, sizeof(int), hd.dim[0], imfile);
			if (bytord) {
				unsigned int *ui = (unsigned int *)pint;
				for (i=0; i<hd.dim[0]; i++)
					ui[i] = ntohl(ui[i]);
			}
			for(i=0; i<hd.dim[0]; i++)
				pfl[i*2+1] = (float)pint[i] * fnorcon;
		} else {
			fread(pint, sizeof(int), 2*hd.dim[0], nmr);
			if (bytord) {
				unsigned int *ui = (unsigned int *)pint;
				for (i=0; i<2*hd.dim[0]; i++)
					ui[i] = htonl(ui[i]);
			}
			for (i=1; i<2*hd.dim[0]; i+=2)
				pint[i] = -pint[i];
			for (i=0; i<2*hd.dim[0]; i++)
				pfl[i] = (float)pint[i];
		}
		unsigned int *ui = (unsigned int *)pfl;
		for (i=0; i<2*hd.dim[0]; i++)
			ui[i] = htonl(ui[i]);
		sock_write(sock, (char *)pfl, 2*sizeof(float)*hd.dim[0]);
	}
	freefh();
	if (pfl) free(pfl);
	if (pint) free(pint);
	if (farray) free(farray);
	if (nmr) fclose(nmr);
	if (refile) fclose(refile);
	if (imfile) fclose(imfile);
	return;
}

/* This waits for all children, so that they don't become zombies. */
static void reaper()
{
#ifdef DEBUG
	int pid;
#endif
	int status;

#ifdef DEBUG
	while ( ( pid = wait3( &status, WNOHANG, NULL ) ) > 0 ) {
		printf("Child %d has be terminated", pid );
	}
#else
	while((wait3(&status, WNOHANG, NULL)) > 0)
		;
#endif
}

int main(int argc, char *argv[])
{
	int sock;
	int connected = 1;
	char buffer[SOCKBUFSIZE];
	char host[MAXHOSTNAMELEN];
#ifdef PASSREQ
	char salt[3];
	char *pcrypt;
#endif
	char *ruser, *luser;
	int port = -1;
	struct stat statbuf;
	static int listensock = -1;
	struct sockaddr inhostaddr;
	int inhostaddr_len;
	struct hostent  *inhost;
	struct passwd *pw;
#ifndef DEBUG
        /* Our process ID and Session ID */
        pid_t pid, sid;
        
        /* Fork off the parent process */
        pid = fork();
        if (pid < 0) {
                exit(EXIT_FAILURE);
        }
        /* If we got a good PID, then
           we can exit the parent process. */
        if (pid > 0) {
                exit(EXIT_SUCCESS);
        }

        /* Change the file mode mask */
        umask(0);
                
        /* Open any logs here */        
                
        /* Create a new SID for the child process */
        sid = setsid();
        if (sid < 0) {
                /* Log the failure */
                exit(EXIT_FAILURE);
        }
        

        
        /* Change the current working directory */
        if ((chdir("/")) < 0) {
                /* Log the failure */
                exit(EXIT_FAILURE);
        }
        
        /* Close out the standard file descriptors */
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);
#endif

	signal(SIGCHLD, reaper );
#ifdef DEBUG
	printf( "Parent process pid = %d\n", getpid() );
#endif
	
	port = atoport( "tefid", "tcp" );
	if ( port == -1 ) {
#ifdef DEBUG
		printf("Unable to find tefid service\n" );
#endif
		exit(-1);
	}

	inhostaddr_len = sizeof( struct sockaddr );
	sock = get_connection( SOCK_STREAM, port, &listensock, &inhostaddr, &inhostaddr_len );
	inhost = gethostbyaddr( inhostaddr.sa_data+2, 4, AF_INET );
	if ( inhost ) {
		strcpy( host, inhost->h_name );
#ifdef DEBUG
		printf("connection from %u:%u:%u:%u (%s)\n", 
			(unsigned char)inhostaddr.sa_data[2],
			(unsigned char)inhostaddr.sa_data[3],
			(unsigned char)inhostaddr.sa_data[4],
			(unsigned char)inhostaddr.sa_data[5],
			host );
#endif
	} else {
		strcpy( host, "UNKNOWN" );
#ifdef DEBUG
		printf("unknown host address %u:%u:%u:%u\n",
			(unsigned char)inhostaddr.sa_data[2],
			(unsigned char)inhostaddr.sa_data[3],
			(unsigned char)inhostaddr.sa_data[4],
			(unsigned char)inhostaddr.sa_data[5] );
#endif
	}
#ifdef PASSREQ
	sock_puts( sock, "NetNMR Server\n");
#else
	sock_puts( sock, "Tefid Server\n" );
#endif
	if ( sock_gets( sock, buffer, SOCKBUFSIZE ) < 0 ) {
		connected = 0;
#ifdef DEBUG
		printf("Cannot confirm Tefid Server" );
#endif
	} else {
		if ( buffer[0] != 'u' ) {
			syslog( LOG_AUTH|LOG_WARNING,
				"%s: expected uid, got '%s'", argv[0], buffer );
			connected = 0;
		} else {
			ruser = buffer+1;
			luser = strchr( ruser, ',' );
			if ( luser == NULL ) {
				syslog( LOG_AUTH|LOG_WARNING,
					"%s: bad uid, '%s'", argv[0], buffer );
				connected = 0;
			} else {
				*luser++ = (char)NULL;
				if ( strcmp( ruser, "mswinuser" ) ) {
					if ( ruserok( host, 0, ruser, luser ) ) {
						syslog( LOG_AUTH|LOG_WARNING,
							"%s: connection from %s@%s to %s refused",
							argv[0], ruser, host, luser );
						connected = 0;
					}
				}
				if ( connected ) {
					pw = getpwnam( luser );
					if ( pw ) {
#ifdef PASSREQ
						sock_puts(sock, "Password?\n");
						if (sock_gets(sock, buffer, SOCKBUFSIZE) < 0) {
							connected = 0;
						} else {
							memcpy(salt, pw->pw_passwd, 2);
							salt[2] = NULL;
							pcrypt = crypt(buffer, salt);
							if (pcrypt) {
								if (strcmp(pcrypt, pw->pw_passwd))
									connected = 0;
							} else
								connected = 0;
						}
						if (connected) {
							setgid( pw->pw_gid );
							setuid( pw->pw_uid );
						}
#else
						setgid( pw->pw_gid );
						setuid( pw->pw_uid );
#endif
					} else {
						syslog( LOG_AUTH|LOG_WARNING,
							"%s: requested user %s (from %s@%s) not found!",
							argv[0], luser, ruser, host );
						connected = 0;
					}
				}
			}
		}
		sock_puts( sock, connected?"ok\n":"disconnect\n" );
	}
	while ( connected ) {
		/* Read input */
		if ( sock_gets( sock, buffer, SOCKBUFSIZE ) < 0 ) {
			connected = 0;
		} else {
#ifdef DEBUG
			printf("COMMAND=%s\n", buffer);
#endif
			switch ( buffer[0] ) {
			case '/':
				changedir( buffer+1 );
				getcwd( buffer, SOCKBUFSIZE-1 );
				if ( 1 < strlen( buffer ) ) strcat( buffer, "/" );
				strcat( buffer, "\n" );
				sock_puts( sock, buffer );
				break;
			case '?':
				sock_puts( sock, stat( buffer+1, &statbuf )?"NO\n":"YES\n" );
				break;
			case '1':
				getspectrum( sock, buffer+1, 1 );
				break;
			case '2':
				getspectrum( sock, buffer+1, 2 );
				break;
			case 'f':
				getfile( sock, buffer+1 );
				break;
			case 'l':
				listdirectory( sock, 0, 1 );
				break;
			case 'L':
				listdirectory( sock, 1, 1 );
				break;
			case 'M':
				listdirectory( sock, 1, 2 );
				break;
			case 'x':
				connected = 0;
				break;
			default:
				sock_puts( sock, "ERROR\n" );
				break;
			}
		}
	}
	shutdown( sock, 2 );
	close( sock );
	exit( 0 );
}
