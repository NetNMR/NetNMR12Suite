#ifndef JCAMP_H
#define JCAMP_H

typedef struct jcparkey {
	char *name;
	int vcount;
	char **value;
} JCPAR;

char *file2mem(char *filename);
int readjcamp(char *filename);
JCPAR *findpar(char *name);
void freepar(void);

#endif
