#define _SGI_REENTRANT_FUNCTIONS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <search.h>

#include "jcamp.h"

static char *pmemfile;
static void *root;

static int parcomp(const void *p1, const void *p2) {
	return strcmp(((const JCPAR *)p1)->name, ((const JCPAR *)p2)->name);
}

char *file2mem(char *filename)
{
    char *fstr = (char *)NULL;
    FILE *fp;
    struct stat statbuf;
    int successful = 0;

    if (! stat(filename, &statbuf)) {
        fstr = calloc(statbuf.st_size + 1, 1);
        if (fstr) {
            fp = fopen(filename, "r");
            if (fp) {
                if (1 == fread(fstr, statbuf.st_size, 1, fp)) {
                    successful = 1;
                    fstr[statbuf.st_size] = 0;
                }
                fclose(fp);
            }
            if (! successful) {
                free(fstr);
                fstr = (char *)NULL;
            }
        }
    }
    return fstr;
}

int readjcamp(char *filename) {
	static char *start = "##$";
	static char *sp = " \t\n";
	char *name, **value;
	int i, npar = 0, vcount;
	char *pstr, *pend;
	JCPAR *ppar;

	pmemfile = file2mem(filename);
	if (NULL == pmemfile) {
		return npar;
	}
	name = strstr(pmemfile, start);
	while (name) {
		value = 0;
		name += strlen(start);
		pend = strchr(name, '=');
		if (pend) {
			*pend = (char)NULL;
			pstr = pend + 1;
			if (strncmp(pstr, " (0..", 5)) {
				vcount = 1;
				value = (char **)malloc(sizeof(char *));
				if (value) {
					if (0 == strncmp(pstr, " <", 2)) {
						value[0] = pstr + 2;
						pend = strchr(value[0], '>');
					} else {
						value[0] = pstr + 1;
						pend = strchr(value[0], '\n');
					}
					*pend = (char)NULL;
					pstr = pend + 1;
					while (isspace(value[0][strlen(value[0])-1]))
						value[0][strlen(value[0])-1] = (char)NULL;
				} else
					vcount = 0;
			} else {
				pstr += 5;
				vcount = atoi(pstr) + 1;
				pstr = strchr(pstr, ')') + 1;
				value = (char **)malloc(vcount * sizeof(char *));
				if (value) {
					pend = NULL;
					value[0] = strtok_r(pstr, sp, &pend);
					for (i=1; i<vcount; i++)
						value[i] = strtok_r(NULL, sp, &pend);
					pstr = pend;
				} else
					vcount = 0;
			}
			if (vcount) {
				ppar = malloc(sizeof(JCPAR));
				if (ppar) {
					ppar->name = name;
					ppar->vcount = vcount;
					ppar->value = value;
					(void)tsearch(ppar, &root, parcomp);
					npar++;
				} else
					free(value);
			}
		}
		name = strstr(pstr, start);
	}
	return npar;
}

void freepar(void) {
	while (root) {
		JCPAR *p = *(JCPAR **)root;
		(void)tdelete(p, (void **)&root, parcomp);
		if (p) {
			if (p->value)
				free(p->value);
			free(p);
		}
	}
	if (pmemfile) {
		free(pmemfile);
		pmemfile = (char *)NULL;
	}
}

JCPAR *findpar(char  *name) {
	JCPAR par, *ppar;
	void *vp;

	par.name = name;
	vp = tfind(&par, &root, parcomp);
	if (vp)
		ppar = (*(JCPAR **)vp);
	else
		ppar = NULL;
	return ppar;
}
