#!/bin/sh

# chkconfig: 2345 99 01
# description: NetNMR file sterver
# processname: nmrserverd 

NMRSERVERD_BIN=/usr/local/tefid/nmrserverd

# Source function library
. /etc/rc.d/init.d/functions

# [ -r /etc/sysconfig/smartmontools ] && . /etc/sysconfig/smartmontools

RETVAL=0
prog=nmrserverd
pidfile=/var/lock/subsys/nmrserverd

start()
{
	echo -n $"Starting $prog: "
	daemon $NMRSERVERD_BIN
	RETVAL=$?
	echo
	[ $RETVAL = 0 ] && touch $pidfile
	return $RETVAL
}

stop()
{
	echo -n $"Shutting down $prog: "
	killproc $NMRSERVERD_BIN
	RETVAL=$?
	echo
	rm -f $pidfile
	return $RETVAL
}

case "$1" in
	start)
		start
		;;
	stop)
		stop
		;;
	restart)
		stop
		start
		;;
	try-restart)
		if [ -f $pidfile ]; then
			stop
			start
		fi
		;;
	status)
		status $prog
		RETVAL=$?
		;;
	*)
		echo $"Usage: $0 {start|stop|restart|try-restart|status}"
		RETVAL=3
esac

exit $RETVAL

