#ifndef OMEGA_HEADER_H
#define OMEGA_HEADER_H
/****************************************************************************
* SECTION NAME:       Static Instrument header definitions
* SECTION CONTENTS:
*                The following structures defined here are used in the Header
*                AIR_CONTROL, ALARM_CONTROL, DEC_CONTROL,  FILT_CONTROL,
*                F1_CONTROL,  GAIN_CONTROL,  LOCK_CONTROL, SPOIL_CONTROL,
*                VT_CONTROL
****************************************************************************/

/* These defines should correspond to the menu position of these items in
	the stop_shim_menu menu in Dshim.c */
#define GAIN	2
#define TXPWR	3
#define FREQ	4
#define OFFSET	5
#define PHASE	6
#define SWIDTH	7
#define SRATE	8

#define LOCK_SWEEP_FRACT 2

/*----------------------------------------------------------------------
 *       Air Control Structure for air commands: spin, eject, bodyair & gas.
 *         For VT see VT_CONTROL.
 */

struct AIR_CONTROL {
	int eject_flag;	/* 680 Eject on/off 1/0                          */
	int spin_state;	/* 684 Spin on/off 1/0                           */
	int spin_rate;		/* 688 Spin rate in hertz                        */
	int spin_val;		/* 692 In dac units 0 to 2047                    */
	int spin_hi_alarm;	/* 696 high spin rate alarm limit                */
	int spin_lo_alarm; /* 700 low spin rate alarm limit                 */
	int body_flag;		/* 704 Body air on/off 1/0                       */
	int gas_flag;		/* 708 Gas N2/air 1/0                            */
	int vt_flag;		/* 712 VT air on/off 1/0                         */
	int vac_flag;		/* 716 Vacuum pump on/off 1/0                    */
};						/* 720 size = 10 words */

typedef struct AIR_CONTROL AIR_CONTROL;

/*----------------------------------------------------------------------
 *       Alarm Control Structure for vtalarm command, etc.
 */

/* Define vtalarm enable/on states, bit-significant. */
#define VT_ALARM_ON		1
#define SPIN_ALARM_ON	2
#define LOCK_ALARM_ON	4

/* Define vtalarm actions, bit-significant. */
#define RESUME_ACTION		0x01
#define ABORT_ACTION		0x02
#define DEC_DIS_ACTION		0x04
#define CSHIM_STP_ACTION	0x08
#define GAS_OFF_ACTION		0x10
#define HEAT_OFF_ACTION		0x20
#define EJECT_ACTION		0x40

struct ALARM_CONTROL {
	int on_flag;			/* 720 */
	int lock_lost;			/* 724 */
	int vt_high;			/* 728 */
	int vt_low;			/* 732 */
	int vt_gas;			/* 736 */
	int spin_high;			/* 740 */
	int spin_low;			/* 744 */
	int unused1;			/* 748 */
};				/* size = 8 words */

typedef struct ALARM_CONTROL ALARM_CONTROL;

/*---------------------------------------------------------------------
 *       Filter Control Structure for filter command.
 */

#define FILT_BES_MODE	2
#define FILT_BUT_MODE	1
#define FILT_DIR_MODE	0

struct FILT_CONTROL {
	float sw_fraction;	/* 1008 Cutoff freq as fraction of sw.             */
	int freq;			/* 1012 Cutoff freq (3 db) of filter in hertz.     */
	int mode;			/* 1016 Mode bessel/butterworth/off.               */
	int preamp;		/* 1020 Preamp filter on/off 1/0.                  */
	int locktrap;		/* 1024 Lock Trap on/off 1/0.                      */
	int freq_override;	/* 1028 Used for freq_override on/off 1/0 Rel 4.4. */
	int unused1;		/* 1032 padding */
	int unused2;		/* 1036 */
};						/* size = 8 words */

typedef struct FILT_CONTROL FILT_CONTROL;

/*---------------------------------------------------------------------
 *       Frequency Control Structure for f1 command.
 *
 *	NOTE: Power values (pwr_val, hi_pwr_val, lo_pwr_val) depend
 *			on System type, either:
 *				attenuation value from 0 - 63, or
 *				DAC value from 0 - 2047.
 */
 
/*	Define bits used in hd->f1.unused1 for Preamp & Selection module.   */
/*	Bits are defined so that (unused1 = 0) gives default settings.      */
#define	F1_HOMO_DISABLE	1	/* Default: homo enabled, Level 1 line #5.  */
#define	F1_SEL_CROSSED	2	/* Default: selection straight, Level 1 #6. */
#define F1_CAL_ON		4	/* Default: cal off, Level 1 line #7.       */

struct F1_CONTROL {
	double freq;		/* 752 Frequency in Mhz.                        */
	double ref_freq;	/* 760 Reference frequency for offset calc      */
	double nu_offset;	/* 768 nucleus offset frequency in ppm          */
	int hi_pwr_flag;	/* 776 High/Low 1/0                             */
	int pwr_val;		/* 780 For Shell & scripts only.                */
	int hi_pwr_val;	/* 784 For SI Task.                    	        */
	int lo_pwr_val;	/* 788 For SI Task.                    	        */
	int cpma_flag;     /* 792 CPMA On/Off 1/0                 	        */
	char nucleus[8];	/* 796 Isotope identification                   */
	int lo_sideband;	/* 804 Low SideBand setting                     */
	int mod_pad;		/* 808 Modulator attenuator in/out 1/0.         */
	int unused1;		/* 812 Starting Rel. 5.1: for Preamp & Select.  */
};						/* size = 16 words */

typedef struct F1_CONTROL F1_CONTROL;

/*---------------------------------------------------------------------
 *       Frequency Control Structure for f2 & f3 commands.
 */

/* Defines for "blank_ctrl" */
#define B_FOLLOW_HB '2'
#define B_ENABLE    '1'
#define B_DISABLE   '0'

/* Defines for "hetero_flag" */
#define HETERO      '2'
#define HOMO        '1'
#define H_OFF       '0'

struct DEC_CONTROL {
	double freq;		/* 816 Frequency in Mhz.                         */
	double ref_freq;	/* 824 Reference frequency for offset calc       */
	double nu_offset;	/* 832 nucleus offset frequency in ppm           */
	float rate;			/* 840 Program rate in hertz                     */
	int on_flag;		/* 844 On/off 1/0                                */
	int atten_state;	/* 848 State 2/State 1 2/1                       */
	int pwr_val;		/* 852 Value from 0 thru 82                      */
	int cw_flag;		/* 856 CW/Program 1/0                            */
	int rom_program;	/* 860 ROM Program number, 0 thru 3              */
	int phase_offset;	/* 864 Phase Offset, 0 90 180 270                */
	int phase_tweak;	/* 868 Phase Tweak, -2048 thru 2047              */
	int time1;			/* 872 Pulse Width in microseconds, 0 - 255      */
 	int time2;			/* 876 Post Delay in microseconds, 0 - 60        */
	int hw_divider;	/* 880 HW frequency divider setting -- RAM only. */
	int l2_pwr_val;	/* 884 Used for 1280 F3 L2 pwr_val               */
	char blank_ctrl;	/* 888 Preamp DX Blanking Ctrl(not used by SI):  */
						/*      follow_hb/enable/disable '2'/'1'/'0'     */
	char blanking;		/* 889 Preamp DX Blanking (used by SI Task):     */
						/*      enable/disable '1'/'0'                   */
	char cpma_flag;		/* 890 Used for cpma_flag on/off '1'/'0' Rel 4.4.*/
	char hetero_flag;	/* 891 Hetero/Homo/off '2'/'1'/'0'               */
	char nucleus[8];	/* 892 Isotope identification                    */
	int mod_pad;		/* 900 Modulator attenuator in/out 1/0.          */
	int unused1;		/* 904 padding */
	int unused2;		/* 908 */
};						/* size = 24 words */

typedef struct DEC_CONTROL DEC_CONTROL;

/*---------------------------------------------------------------------
 *       Gain Control Structure for gain command.
 */

struct GAIN_CONTROL {
	float gain_val;		/* 1040 Value of gain, 1 thru 10,000.            */
	int mode;			/* 1044 Cmd mode, when = 1, user controls attn's.*/
	int if_on;			/* 1048 IF Attenuator In/Out 1/0.                */
	int rf_on;			/* 1052 RF Attenuator In/Out 1/0.                */
	int af_on;			/* 1056 AF Amplifier On/Off 1/0.                 */
	int unused1;		/* 1060 padding */
};						/* size = 6 words */

typedef struct GAIN_CONTROL GAIN_CONTROL;

/*---------------------------------------------------------------------
 *       Lock Control Structure for lock command.
 */

struct LOCK_CONTROL {
	double freq;		/* 1064 Freq in Mhz.                              */
	double ref_freq;	/* 1072 Reference frequency for offset calc       */
	double nu_offset;	/* 1080 nucleus offset frequency in ppm           */
	float delta;		/* 1088 The change in Freq or Field during sweep. */
	int state;			/* 1092 On/off 1/0                                */
	int mode;			/* 1096 Fast/slow/standby 2/1/0                   */
	int gain;			/* 1100 In dac units 0 to 2047.                   */
	int power;			/* 1104 In dac units 0 to 2047.                   */
	int offset;		/* 1108 In dac units 0 to 2047.                   */
	int phase;			/* 1112 In dac units 0 to 2047.                   */
	int sweep;			/* 1116 Frequency/field/off 2/1/0                 */
	int type;			/* 1120 Triangular/sawtooth 1/0                   */
	int buff_size;		/* 1124 Must be >= 4                              */
	int dwell;			/* 1128 In microseconds.                          */
	int lo_alarm;		/* 1132 Lower lock level alarm value.             */
	char nucleus[8];	/* 1136 Isotope identification                    */
};						/* size = 20 words */

typedef struct LOCK_CONTROL LOCK_CONTROL;

/*---------------------------------------------------------------------
 *       Homospoil Control Structure for spoil command.
 */

struct SPOIL_CONTROL {
	int x_val;	/* 1144 Delta amount of DAC units to change X Coarse Shim DAC.   */
	int y_val;	/* 1148 Delta amount of DAC units to change Y Coarse Shim DAC.   */
	int z_val;	/* 1152 Delta amount of DAC units to change Z1 Coarse Shim DAC.  */
	int unused1; /* 1156 */
};

typedef struct SPOIL_CONTROL SPOIL_CONTROL;

/*---------------------------------------------------------------------
 *       VT Control Structure for vt command.
 */

struct VT_CONTROL {
	float	set_point;		/* 1160 Desired temperature in degrees C */
	float	hi_alarm;		/* 1164 High alarm temperature           */
	float	lo_alarm;		/* 1168 Low alarm temperature            */
	int		state;		/* 1172 VT on/off 1/0                    */
	int		unused1;	/* 1176 padding */
	int		unused2;	/* 1180 */
};					/* size = 6 words */

typedef struct VT_CONTROL VT_CONTROL;

/****************************************************************************
* SECTION NAME:       Top level sane header definition
* SECTION CONTENTS:
*	These are the parameters that form the sane structset header, hdsane.
****************************************************************************/

struct SANE_HD              /* sane header structset, hdsane*/
{							/*  Offset, in bytes from beginning of file */
	double cf_current;		/*  288 config freq including offset (Mhz) */
	double cf_base;		    /*  296 config freq that puts TMS in proton spect */
	double spec_width[4];   /*  304 Spectral width (hz) */
	double dim_freq[4];	    /*  336 Frequency for corresponding dimension */
	double dwell_time[4];	/*  368 Dwell time (sec) */
	double at;				/*  400 Acquisition time (sec) */
	double de;				/*  408 Acq delay (usec) */
	double rg;				/*  416 Receiver gate pulse */
	double de_dw_ratio; 	/*  424 just what it says... */
	float fov[4];			/*  432 Field of View (mm) for images */
	float gain_corr;		/*  448 ADC Gain correction */
	float phase_corr;		/*  452 ADC Phase correction */
	float iphase;			/*  456 ADC Initial Phase */
	float incphase;         /*  460 ADC Incremental Phase */
	float of[4];			/*  464 spectrum offset (Hz) */
	float phasea[4];		/*  480 Total 0th order phase correction applied */
	float phaseb[4];		/*  496 Total 1st order phase correction applied */
	float data_maximum;	    /*  512 Data maximum - used in display routines */
	float data_minimum;	    /*  516 Data minimum - used in display routines */
	float dis_floor;		/*  520 Display floor in percent */
	int dim[4];			/*  524 size in each dim (complex points) */
	int ftflag[4];		    /*  540 0=>for fid; 1=>spectrum */
	int spec_rev[4];	    /*  556 spectrum reverse req'd during processing */
	int block_size;		/*  572 size of fid in complex points */
	int groupnum;		    /*  576 number of view groups */
	int groupcur;		    /*  580 current view group */
	int dimension;		    /*  584 data set dimension (1..4) */
	int hetero_flag;	    /*  588 flag for hetero nuclear experiment */
	int sample_number;     /*  592 sample changer sample number */
	int adcmemsize;		/*  596 ADC Memory size */
	int phase_cycle;	    /*  600 number of acq per phase cycle */
	int na;				/*  604 Number of acquisitions */
	int nac;			    /*  608 Number of acquisitions start count */
	int nb;				/*  612 Number of Blocks */
	int nbc;				/*  616 Number of Blocks start count */
	int nc;				/*  620 additional limits */
	int ncc;				/*  624 and counters....  */
	int nd;				/*  628 */
	int ndc;				/*  632 */
	int nq;				/*  636 Number of echos */
	int nqc;				/*  640 Number of echos count */
	int ns;				/*  644 */
	int nsc;				/*  648 sequence counter */
	int dg;				/*  652 number of sequences w/o triggers */
	int dgc;				/*  656 counter 0 .. dg */
	int acqmode;			/*  660 0="raw" or 1="alt" */
	int channel;			/*  664 ADC Channel ('A' or 'B') */
	int trigsrc;			/*  668 ADC Trigger Source ('I' or 'X') */
	int extdw;				/*  672 External Dwell 0=off, 1=on */
	int unused1;			/*  676 size = 98 wds THRU this point */
	AIR_CONTROL		air;	/*  680 10 wds */
	ALARM_CONTROL	alarm;	/*  720 8 wds */
	F1_CONTROL		f1;		/*  752 16 wds */
	DEC_CONTROL		f2;		/*  816 24 wds */
	DEC_CONTROL		f3;		/*  912 24 wds */
	FILT_CONTROL	filter;	/* 1008 8 wds */
	GAIN_CONTROL	gain;	/* 1040 6 wds */
	LOCK_CONTROL	lock;	/* 1064 20 wds */
	SPOIL_CONTROL	spoil;	/* 1144 4 wds */
	VT_CONTROL		vt;		/* 1160 6 wds */
};							/* 1184 size = 224 words*/

typedef struct SANE_HD SANE_HD;

#endif
